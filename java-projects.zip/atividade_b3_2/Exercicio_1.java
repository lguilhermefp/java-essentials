package atividade_b3_2;

public class Exercicio_1 {
//Interfaces sao como classes, mas com apenas com metodos vazios que serao obrigatoriamente escritos nas classes que as implementarem.
//As classes que implementarem uma interface deverao sobrescrever todos seus m�todos, obrigatoriamente.
}
