package atividade_b4_1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Exercicio_3 {
    public static void main(String[] args) {
    	
    	System.out.println(new File("arquivo.java").getAbsoluteFile());
    	File file = new File("C:\\Users\\Usu�rio\\eclipse-workspace\\PC2 2020 EAD - Atividades\\arquivo.java".trim());
    	
    	System.out.println("The path is '" + "C:\\Users\\Usu�rio\\eclipse-workspace\\PC2 2020 EAD - Atividades\\arquivo.java".trim() + "'");
    	
    	System.out.println(file.exists());
    	
        try (FileReader leitor = new FileReader("atividade_b4_1\\arquivo.java")){
            var valor = leitor.read();
            Scanner x = new Scanner(leitor);
            int contador=0;
            for(int i=0; i<=100; i++) {
            	if(x.hasNextByte()==true) {
            		contador++;
            	}
            }
            System.out.println(contador);
        }
        catch (FileNotFoundException e) {
            System.out.println("Foi capturada a FileNotFoundException (mais espeficica)");
        } catch (IOException e) {
            System.out.println("Foi capturada a IOException (generica)");
        }
    }
}