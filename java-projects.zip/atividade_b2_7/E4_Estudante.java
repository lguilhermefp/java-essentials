package atividade_b2_7;

public class E4_Estudante extends E4_Pessoa {

	public static int ano;
	
	public int getAno() {return ano;}
	
	public void setAno(int ano) {this.ano = ano;}
}
