package atividade_b2_7;

public class E4_Pessoa {

	private String nome, endereco, email, numeroTelefone;
	
	public String getNome() {return nome;}
	public String getEndereco() {return endereco;}
	public String getEmail() {return email;}
	public String getNumeroTelefone() {return numeroTelefone;}
	
	public void setNome(String nome) {this.nome = nome;}
	public void setEndereco(String endereco) {this.endereco = endereco;}
	public void setEmail(String email) {this.email = email;}
	public void setNumeroTelefone(String numeroTelefone) {this.numeroTelefone = numeroTelefone;}
}
