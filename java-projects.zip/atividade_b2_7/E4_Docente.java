package atividade_b2_7;

public class E4_Docente extends E4_Funcionario {

	private String horarioTrabalho, titula��o;
	
	public String getHorarioTrabalho() {return horarioTrabalho;}
	public String getTitula��o() {return titula��o;}
	
	public void setHorarioTrabalho(String horarioTrabalho) {this.horarioTrabalho = horarioTrabalho;}
	public void setTitula��o(String titula��o) {this.titula��o = titula��o;}
}
