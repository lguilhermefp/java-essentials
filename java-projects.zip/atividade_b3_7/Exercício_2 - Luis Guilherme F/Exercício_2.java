package atividade_b3_7;

public class Exerc�cio_2 {

//	Um trecho de codigo unreachable e um trecho que e impossivel de ser alcancado por depender de uma condicao impossivel
//	Um exemplo de tal situa��o � quando h� uma atribui��o como "int a = 0;" que ocorre incondicionalmente num m�todo void apos o "return;"
}
