package atividade_b3_3;

public class Exerc�cio_2 {
//a) Verdadeira
//b) Verdadeira
//c) Falsa. O objeto da classe que implementa uma interface pode ter qualquer tipo.
}
