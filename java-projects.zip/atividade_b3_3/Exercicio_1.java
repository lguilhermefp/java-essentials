package atividade_b3_3;

public class Exercicio_1 {
//a) abstrata
//b) p�blicas
//c) abstract
}
