package atividade_b3_3;

public class Exerc�cio_3 {
//Exerc�cio C. M�todo "Parar" devia ser abstrato.
}
