package atividade_8;

public class Exerc�cio_2 {
	/*
	 * a) 20*15*10 = 3000 repeti��es
	 * 
	 * b) 1000*500*100 = 50000000 segundos
	*/
}
