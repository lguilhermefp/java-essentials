package atividade_8;

public class Exerc�cio_9 {

	Exerc�cio_9(){
		System.out.println("a	a^2	a^3");
		for(int i=1; i<=10; i++) {System.out.println(i+"	"+i*i+"	"+i*i*i);}
	}
	
	public static void main(String[] args) {
		
		new Exerc�cio_9();
	}
}
