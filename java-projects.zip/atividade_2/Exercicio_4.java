package atividade_2;

public class Exercicio_4 {

	String a = "11";
	int b = 11;
	System.out.println(a==b);
	
}
