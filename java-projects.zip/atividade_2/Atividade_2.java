package atividade_2;

public class Atividade_2 {

	long x = (long)Math.pow(2, 33);
	
	
	public static void main(String[] args) {
		
		String nome = "Gui";
		String endereco = "Rua 3";
		String telefone = "+0 (00)98888-8888";
		
	System.out.println("O "+nome+" no endere�o "+endereco+" e telefone "+telefone+" n�o possui nenhum tipo de pend�ncia.");	
	}

}