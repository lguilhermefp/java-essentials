package atividade_2;

public class Exercicio_1 {
	
	public static void main(String[] args) {
		
		String nome = "Gui";
		float salario = 5000.00f;
		char sexo = 'M';
		int idade = 18;
		String estadoCivil = "casado";
	
		System.out.println("O trabalhador "+nome+" do sexo "+sexo+", idade "+idade+", estado c�vil "+estadoCivil+" e sal�rio "+salario+" encontra-se empregado "
				+ "neste estabelecimento.");
	}
}
