package atividade_b3_8;

public class MyArraySizeException extends MyException {
	public MyArraySizeException(){
	      super("Tamanho invalido");
	    }
}
