package atividade_b2_2;

public class Exerc�cio_4_ResultadosArrays {

	public static void main(String[] args) {
		
		int vetor1[] = new int[Exerc�cio_4_Cria��oArrays.tamanhoVetor];
		vetor1 = Exerc�cio_4_Cria��oArrays.Cria��oArrays(100);
		
		Exerc�cio_4_Multiplica��oArrays.Multiplica��o(vetor1);
		Exerc�cio_4_SomaArrays.Soma(vetor1);
	}
}
