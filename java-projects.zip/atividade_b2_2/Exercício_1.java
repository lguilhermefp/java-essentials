/* A palavra reservada this pode ser usada num m�todo para fazer ref�rencia a uma var�avel de inst�ncia quando houver um par�metro
 * com o mesmo nome dela
 */
