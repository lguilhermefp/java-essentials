package atividade_6;

public class Exemplos {
	
	Exemplos(){
		int array[] = new int[2];
		array[0] = (int)0.1;
		
		int x = 0;
		
		double array2[] = new double[2];
		array2[0] = x;
	}
	
	public static void main(String[] args) {
		new Exemplos();
	}
	
}
