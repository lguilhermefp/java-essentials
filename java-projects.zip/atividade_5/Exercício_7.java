package atividade_5;

public class Exerc�cio_7 {

	Exerc�cio_7(){
		double raio=5.5;
		double per�metro = 2*raio*Math.PI;
		double �rea = raio*raio*Math.PI;
		System.out.println("C�rculo de raio "+raio+" possui per�metro "+per�metro+" e �rea "+�rea);
	}
	
	public static void main(String[] args) {
		new Exerc�cio_7();
	}
}
