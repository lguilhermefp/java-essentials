package atividade_b3_5;

public class Exercicio_7_Esteira {

	int comprimento;
	
	Exercicio_7_Esteira(){
		Exercicio_7_Pessoa.correr(1);
		Exercicio_7_Pessoa.correr(3);
		Exercicio_7_Pessoa.correr(8);
		Exercicio_7_Gato.correr(1);
		Exercicio_7_Gato.correr(3);
		Exercicio_7_Gato.correr(8);
		Exercicio_7_Robo.correr(1);
		Exercicio_7_Robo.correr(3);
		Exercicio_7_Robo.correr(8);
	}
}
