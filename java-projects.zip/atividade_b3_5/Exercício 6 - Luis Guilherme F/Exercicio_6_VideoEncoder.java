package atividade_b3_5;

public class Exercicio_6_VideoEncoder {
    public void encode(Exercicio_6_Video video) {
        System.out.println("Processando video...");
        System.out.println("Pronto!\n");
    }
}
