package atividade_b3_5;

public class Exercicio_6_ServicoDeEmail {
    public void sendEmail(Exercicio_6_Usuario usuario) {
        System.out.println("Enviando notificação para " + usuario.getEmail() + "...");
        System.out.println("Pronto!\n");
    }
}
