package atividade_b3_5;

public class Exercicio_6_Usuario {

    private String email;

    public Exercicio_6_Usuario(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
