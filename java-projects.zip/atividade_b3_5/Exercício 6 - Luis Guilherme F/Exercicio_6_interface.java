package atividade_b3_5;

public interface Exercicio_6_interface {
	/*encoder.*/void encode(Exercicio_6_Video video);
	/*database.*/void store(Exercicio_6_Video video);
	/*emailService.*/void sendEmail(Exercicio_6_Usuario usuario);
}
